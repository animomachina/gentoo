#!/bin/sh

# NEOFETCH
#-----------------------------------------
# USER
printf "Removing current neofetch configuration file '/home/animo/.config/neofetch/config.conf' for user 'animo'\n"
rm -v "/home/animo/.config/neofetch/config.conf"
printf "Removed current neofetch configuration file '/home/animo/.config/neofetch/config.conf' for user 'animo'\n"
printf "Copying 'matrix' neofetch configuration file '/home/animo/backups/neofetch/matrix/config.conf' to '/home/animo/.config/neofetch' for user 'animo'\n"
cp -pv "/home/animo/backups/neofetch/matrix/config.conf" "/home/animo/.config/neofetch"
printf "Copied 'matrix' neofetch configuration file '/home/animo/backups/neofetch/matrix/config.conf' to '/home/animo/.config/neofetch' for user 'animo'\n"
# NEOFETCH USER REMOVE CURRENT BACKUP
printf "Removing 'current' neofetch backup configuration file '/home/animo/backups/neofetch/current/config.conf' for user 'animo'\n"
rm -v "/home/animo/backups/neofetch/current/config.conf"
printf "Removed 'current' neofetch backup configuration file '/home/animo/backups/neofetch/current/config.conf' for user 'animo'\n"
# NEOFETCH USER COPY NEW TO CURRENT BACKUP
printf "Copying current neofetch  configuration file '/home/animo/.config/neofetch/config.conf' to '/home/animo/backups/neofetch/current' for user 'animo'\n"
cp -pv "/home/animo/.config/neofetch/config.conf" "/home/animo/backups/neofetch/current"
printf "Copied current neofetch configuration file '/home/animo/.config/neofetch/config.conf' to '/home/animo/backups/neofetch/current' for user 'animo'\n"
# ROOT
printf "Removing current neofetch configuration file '/root/.config/neofetch/config.conf' for user 'root'\n"
rm -v "/root/.config/neofetch/config.conf"
printf "Removed current neofetch configuration file '/root/.config/neofetch/config.conf' for user 'root'\n"
printf "Copying 'matrix' neofetch configuration file '/root/backups/neofetch/matrix/config.conf' to '/root/.config/neofetch' for user 'root'\n"
cp -pv "/root/backups/neofetch/matrix/config.conf" "/root/.config/neofetch"
printf "Copied 'matrix' neofetch configuration file '/root/backups/neofetch/matrix/config.conf' to '/root/.config/neofetch' for user 'root'\n"
# NEOFETCH ROOT REMOVE CURRENT BACKUP
printf "Removing 'current' neofetch backup configuration file '/root/backups/neofetch/current/config.conf' for user 'root'\n"
rm -v "/root/backups/neofetch/current/config.conf"
printf "Removed 'current' neofetch backup configuration file '/root/backups/neofetch/current/config.conf' for user 'root'\n"
# NEOFETCH ROOT COPY NEW TO CURRENT BACKUP
printf "Copying current neofetch configuration file '/root/.config/neofetch/config.conf' to '/root/backups/neofetch/current' for user 'root'\n"
cp -pv "/root/.config/neofetch/config.conf" "/root/backups/neofetch/current"
printf "Copied current neofetch configuration file '/root/.config/neofetch/config.conf' to '/root/backups/neofetch/current' for user 'root'\n"

# HTOP
#-----------------------------------------
# USER
printf "Removing current htop configuration file '/home/animo/.config/htop/htoprc' for user 'animo'\n"
rm -v "/home/animo/.config/htop/htoprc"
printf "Removed current htop configuration file '/home/animo/.config/htop/htoprc' for user 'animo'\n"
printf "Copying 'matrix' htop configuration file '/home/animo/backups/htop/matrix/htoprc' to '/home/animo/.config/htop' for user 'animo'\n"
cp -pv "/home/animo/backups/htop/matrix/htoprc" "/home/animo/.config/htop"
printf "Copied 'matrix' htop configuration file '/home/animo/backups/htop/matrix/htoprc' to '/home/animo/.config/htop' for user 'animo'\n"
# HTOP USER REMOVE CURRENT BACKUP
printf "Removing 'current' htop backup configuration file '/home/animo/backups/htop/current/htoprc' for user 'animo'\n"
rm -v "/home/animo/backups/htop/current/htoprc"
printf "Removed 'current' htop backup configuration file '/home/animo/backups/htop/current/htoprc' for user 'animo\n"
# HTOP USER COPY NEW TO CURRENT BACKUP
printf "Copying current htop configuration file '/home/animo/.config/htop/htoprc' to '/home/animo/backups/htop/current' for user 'animo'\n"
cp -pv "/home/animo/.config/htop/htoprc" "/home/animo/backups/htop/current"
printf "Copied current htop configuration file '/home/animo/.config/htop/htoprc' to '/home/animo/backups/htop/current' for user 'animo'\n"

# ROOT
printf "Removing current htop configuration file '/root/.config/htop/htoprc' for user 'root'\n"
rm -v "/root/.config/htop/htoprc"
printf "Removed current htop configuration file '/root/.config/htop/htoprc for user 'root'\n"
printf "Copying 'matrix' htop configuration file '/root/backups/htop/matrix/htoprc' to '/root/.config/htop' for user 'root'\n"
cp -pv "/root/backups/htop/matrix/htoprc" "/root/.config/htop"
printf "Copied 'matrix' htop configuration file '/root/backups/htop/matrix/htoprc to '/root/.config/htop' for user 'root'\n"
# HTOP ROOT REMOVE CURRENT BACKUP
printf "Removing current htop backup configuration file '/root/backups/htop/current/htoprc' for user 'root'\n"
rm -v "/root/backups/htop/current/htoprc"
printf "Removed current htop backup configuration file '/root/backups/htop/current/htoprc' for user 'root'\n"
# HTOP ROOT COPY NEW TO CURRENT BACKUP
printf "Copying current htop configuration file '/root/.config/htop/htoprc' to '/root/backups/htop/current' for user 'root'\n"
cp -pv "/root/.config/htop/htoprc" "/root/backups/htop/current"
printf "Copied current htop configuration file '/root/.config/htop/htoprc' to '/root/backups/htop/current' for user 'root'\n"

# .BASHRC
#-----------------------------------------
# USER
printf "Removing current '.bashrc' file '/home/animo/.bashrc' for user 'animo'\n"
rm -v "/home/animo/.bashrc"
printf "Removed current '.bashrc' file '/home/animo/.bashrc' for user 'animo'\n"
printf "Copying 'matrix' '.bashrc' file '/home/animo/backups/dotfiles/.bashrc/matrix/.bashrc' to '/home/animo' for user 'animo'\n"
cp -pv "/home/animo/backups/dotfiles/.bashrc/matrix/.bashrc" "/home/animo"
printf "Copied 'matrix' '.bashrc' file '/home/animo/backups/dotfiles/.bashrc/matrix/.bashrc' to '/home/animo' for user 'animo'\n"

# .BASHRC USER REMOVE CURRENT BACKUP
printf "Removing current '.bashrc' backup file '/home/animo/backups/dotfiles/.bashrc/current/.bashrc' for user 'animo'\n"
rm -v "/home/animo/backups/dotfiles/.bashrc/current/.bashrc"
printf "Removed current '.bashrc' backup file '/home/animo/backups/dotfiles/.bashrc/current/.bashrc' for user 'animo'\n"
# .BASHRC USER COPY NEW TO CURRENT BACKUP
printf "Copying current '.bashrc' file '/home/animo/.bashrc' to '/home/animo/backups/dotfiles/.bashrc/current' for user 'animo'\n"
cp -pv "/home/animo/.bashrc" "/home/animo/backups/dotfiles/.bashrc/current"
printf "Copied current '.bashrc file '/home/animo/.bashrc' to '/home/animo/backups/dotfiles/.bashrc/current' for user 'animo'\n"

# ROOT
printf "Removing current '.bashrc' file '/root/.bashrc' for user 'root'\n"
rm -v "/root/.bashrc"
printf "Removed '.bashrc' file '/root/.bashrc' for user 'root'\n"
printf "Copying 'matrix' '.bashrc' file '/root/backups/dotfiles/.bashrc/matrix/.bashrc' to '/root' for user 'root'\n"
cp -pv "/root/backups/dotfiles/.bashrc/matrix/.bashrc" "/root"
printf "Copied 'matrix' '.bashrc' file '/root/backups/dotfiles/.bashrc/matrix/.bashrc' to '/root' for user 'root'\n"

# .BASHRC ROOT REMOVE CURRENT BACKUP
printf "Removing current '.bashrc' backup file '/root/backups/dotfiles/.bashrc/current/.bashrc' for user 'root'\n"
rm -v "/root/backups/dotfiles/.bashrc/current/.bashrc"
printf "Removed current '.bashrc' backup file '/root/backups/dotfiles/.bashrc/current/.bashrc' for user 'root'\n"
# .BASHRC ROOT COPY NEW TO CURRENT BACKUP
printf "Copying current '.bashrc' file '/root/.bashrc' to '/root/backups/dotfiles/.bashrc/current' for user 'root'\n"
cp -pv "/root/.bashrc" "/root/backups/dotfiles/.bashrc/current"
printf "Copied current '.bashrc' file '/root/.bashrc' to '/root/backups/dotfiles/.bashrc/current' for user 'root'\n"

# SUCKLESS ST UNINSTALL
#-----------------------------------------
printf "Uninstalling currently installed 'st terminal emulator'\n"
make -C "/home/animo/suckless/st/" clean uninstall
printf "Uninstalled 'st terminal emulator'\n"
printf "Removing old 'st terminal emulator directory' '/home/animo/suckless/st'\n"
rm -rv "/home/animo/suckless/st"
printf "Removed old 'st terminal emulator directory' '/home/animo/suckless/st'\n"

# SUCKLESS DWM UNINSTALL
#-----------------------------------------
printf "Uninstalling currently installed 'dwm window manager'\n"
make -C "/home/animo/suckless/dwm" clean uninstall
printf "Uninstalled 'dwm window manager'\n"
printf "Removing old 'dwm window manager' directory '/home/animo/suckless/dwm'\n"
rm -rv "/home/animo/suckless/dwm"
printf "Removed old 'dwm window manager' directory '/home/animo/suckless/dwm'\n"

# COPY DWM TO SUCKLESS DIRECTORY
#-----------------------------------------
printf "Copying 'matrix' 'dwm window manager' files to '/home/animo/suckless'\n"
cp -prv "/home/animo/backups/suckless/dwm/matrix/dwm" "/home/animo/suckless"
printf "Copied 'matrix' 'dwm window manager'files to '/home/animo/suckless'\n"

# SUCKLESS DWM INSTALL
#-----------------------------------------
printf "Installing 'matrix' 'dwm window manager'\n"
make -C "/home/animo/suckless/dwm" clean install
printf "Installed 'matrix' 'dwm window manager'\n"

# SUCKLESS DWM DELETE CURRENT BACKUP 
#-----------------------------------------
printf "Removing old 'dwm window manager' files in '/home/animo/backups/suckless/dwm/current'\n"
rm -rv "/home/animo/backups/suckless/dwm/current"
mkdir -p "/home/animo/backups/suckless/dwm/current"
printf "Removed old 'dwm window manager' files in '/home/animo/backups/suckless/dwm/current'\n"

# SUCKLESS DWM COPY NEW TO CURRENT BACKUP
#-----------------------------------------
printf "Copying 'matrix' 'dwm window manager' files to '/home/animo/backups/suckless/dwm/current' for user 'animo'\n"
cp -prv "/home/animo/suckless/dwm" "/home/animo/backups/suckless/dwm/current"
printf "Copied 'matrix' 'dwm window manager' files to '/home/animo/backups/suckless/dwm/current' for user 'animo'\n"

# SUCKLESS DWM REMOVE CONFIG.H IN CURRENT BACKUP
printf "Removing 'matrix' 'dwm window manager' file '/home/animo/backups/suckless/dwm/current/dwm/config.h' for user 'animo'\n"
rm -v "/home/animo/backups/suckless/dwm/current/dwm/config.h"
printf "Removed 'matrix' 'dwm window manager' file '/home/animo/backups/suckless/dwm/current/dwm/config.h' for user 'animo'\n"

# COPY ST TO SUCKLESS DIRECTORY
#-----------------------------------------
printf "Copying 'matrixnoalpha' 'st terminal emulator' files '/home/animo/backups/suckless/st/matrixnoalpha/st' to new 'st terminal emulator' directory '/home/animo/suckless'\n"
cp -prv "/home/animo/backups/suckless/st/matrixnoalpha/st" "/home/animo/suckless"
printf "Copied 'matrixnoalpha' 'st terminal emulator' files '/home/animo/backups/suckless/st/matrixnoalpha/st' to new 'st terminal emulator' directory '/home/animo/suckless'\n"

# SUCKLESS ST INSTALL
#-----------------------------------------
printf "Installing 'matrix' 'st terminal emulator'\n"
make -C "/home/animo/suckless/st" clean install
printf "Installed 'matrix' 'st terminal emulator'\n"

# SUCKLESS ST DELETE CURRENT BACKUP
#-----------------------------------------
printf "Removing 'current' 'st terminal emulator' files in '/home/animo/backups/suckless/st/current' for user 'animo'\n"
rm -rv "/home/animo/backups/suckless/st/current"
mkdir -p "/home/animo/backups/suckless/st/current"
printf "Removed 'current' 'st terminal emulator' files in '/home/animo/backups/suckless/st/current' for user 'animo'\n"

# SUCKLESS ST COPY NEW TO CURRENT BACKUP
#-----------------------------------------
printf "Copying 'matrixnoalpha' st files to '/home/animo/backups/suckless/st/current' directory\n"
cp -prv "/home/animo/suckless/st" "/home/animo/backups/suckless/st/current"
printf "Copied 'matrixnoalpha' st files to '/home/animo/backups/suckless/st/current' directory\n"

# SUCKLESS ST REMOVE CONFIG.H IN CURRENT BACKUP
printf "Removing 'matrixnoalpha' 'st terminal emulator' file '/home/animo/backups/suckless/st/current/st/config.h' for user 'animo'\n"
rm -v "/home/animo/backups/suckless/st/current/st/config.h"
printf "Removed 'matrixnoalpha' 'st terminal emulator' file '/home/animo/backups/suckless/st/current/st/config.h' for user 'animo'\n"


# .XINITRC
#-----------------------------------------
printf "Removing current '.xinitrc' file '/home/animo/.xinitrc' for user 'animo'\n"
rm -v "/home/animo/.xinitrc"
printf "Removed current '.xinitrc' file '/home/animo/.xinitrc' for user 'animo'\n"
printf "Copying 'matrixnoalpha' '.xinitrc' file '/home/animo/backups/dotfiles/.xinitrc/matrixnoalpha/.xinitrc' to '/home/animo/.xinitrc' for user 'animo'\n"
cp -pv "/home/animo/backups/dotfiles/.xinitrc/matrixnoalpha/.xinitrc" "/home/animo"
printf "Copied 'matrix' '.xinitrc' file '/home/animo/backups/dotfiles/.xinitrc/matrixnoalpha/.xinitrc' to '/home/animo/.xinitrc' for user 'animo'\n"

# .XINITRC DELETE CURRENT BACKUP
#-----------------------------------------
printf "Removing 'current' '.xinitrc' backup file '/home/animo/backups/dotfiles/.xinitrc/current/.xinitrc' for user 'animo'\n"
rm -v "/home/animo/backups/dotfiles/.xinitrc/current/.xinitrc"
printf "Removed 'current' '.xinitrc' backup file '/home/animo/backups/dotfiles/.xinitrc/current/.xinitrc' for user 'animo'\n"

# .XINITRC COPY NEW CURRENT BACKUP
#-----------------------------------------
printf "Copying current '.xinitrc' file '/home/animo/.xinitrc' to '/home/animo/backups/dotfiles/.xinitrc/current' for user 'animo'\n"
cp -pv "/home/animo/.xinitrc" "/home/animo/backups/dotfiles/.xinitrc/current"
printf "Copied current '.xinitrc' file '/home/animo/.xinitrc' to '/home/animo/backups/dotfiles/.xinitrc/current' for user 'animo'\n"

# .BASH_PROFILE
#-----------------------------------------
printf "Removing current '.bash_profile' file '/home/animo/.bash_profile' for user 'animo'\n"
rm -v "/home/animo/.bash_profile"
printf "Removed current '.bash_profile' file '/home/animo/.bash_profile' for user 'animo'\n"
printf "Copying 'matrix' '.bash_profile' file '/home/animo/backups/dotfiles/.bash_profile/x/.bash_profile' to '/home/animo' for user 'animo'\n"
cp -pv "/home/animo/backups/dotfiles/.bash_profile/x/.bash_profile" "/home/animo"
printf "Copied 'matrix' '.bash_profile' file '/home/animo/backups/dotfiles/.bash_profile/x/.bash_profile' to '/home/animo' for user 'animo'\n"

# .BASH_PROFILE REMOVE CURRENT BACKUP
#-----------------------------------------
printf "Removing 'current' '.bash_profile' backup file '/home/animo/backups/dotfiles/.bash_profile/current/.bash_profile' for user 'animo'\n"
rm -v "/home/animo/backups/dotfiles/.bash_profile/current/.bash_profile"
printf "Removed 'current' '.bash_profile' backup file '/home/animo/backups/dotfiles/.bash_profile/current/.bash_profile' for user 'animo\n"

# .BASH_PROFILE COPY NEW CURRENT BACKUP
#-----------------------------------------
printf "Copying current '.bash_profile' file '/home/animo/.bash_profile' to '/home/animo/backups/dotfiles/.bash_profile/current' for user 'animo'\n"
cp -pv "/home/animo/.bash_profile" "/home/animo/backups/dotfiles/.bash_profile/current"
printf "Copied current '.bash_profile' file '/home/animo/.bash_profile' to '/home/animo/backups/dotfiles/.bash_profile/current' for user 'animo'\n"

printf "Done.\n"
