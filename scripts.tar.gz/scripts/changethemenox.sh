#!/bin/sh

# NEOFETCH
#-----------------------------------------
# USER
printf "Removing current neofetch configuration file '/home/animo/.config/neofetch/config.conf' for user 'animo'\n"
rm -v "/home/animo/.config/neofetch/config.conf"
printf "Removed current neofetch configuration file '/home/animo/.config/neofetch/config.conf' for user 'animo'\n"
printf "Copying 'red' neofetch configuration file '/home/animo/backups/neofetch/red/config.conf' to '/home/animo/.config/neofetch' for user 'animo'\n"
cp -pv "/home/animo/backups/neofetch/red/config.conf" "/home/animo/.config/neofetch"
printf "Copied 'red' neofetch configuration file '/home/animo/backups/neofetch/red/config.conf' to '/home/animo/.config/neofetch' for user 'animo'\n"
# NEOFETCH USER REMOVE CURRENT BACKUP
printf "Removing 'current' neofetch backup configuration file '/home/animo/backups/neofetch/current/config.conf' for user 'animo'\n"
rm -v "/home/animo/backups/neofetch/current/config.conf"
printf "Removed 'current' neofetch backup configuration file '/home/animo/backups/neofetch/current/config.conf' for user 'animo'\n"
# NEOFETCH USER COPY NEW TO CURRENT BACKUP
printf "Copying current neofetch  configuration file '/home/animo/.config/neofetch/config.conf' to '/home/animo/backups/neofetch/current' for user 'animo'\n"
cp -pv "/home/animo/.config/neofetch/config.conf" "/home/animo/backups/neofetch/current"
printf "Copied current neofetch configuration file '/home/animo/.config/neofetch/config.conf' to '/home/animo/backups/neofetch/current' for user 'animo'\n"
# ROOT
printf "Removing current neofetch configuration file '/root/.config/neofetch/config.conf' for user 'root'\n"
rm -v "/root/.config/neofetch/config.conf"
printf "Removed current neofetch configuration file '/root/.config/neofetch/config.conf' for user 'root'\n"
printf "Copying 'red' neofetch configuration file '/root/backups/neofetch/red/config.conf' to '/root/.config/neofetch' for user 'root'\n"
cp -pv "/root/backups/neofetch/red/config.conf" "/root/.config/neofetch"
printf "Copied 'red' neofetch configuration file '/root/backups/neofetch/red/config.conf' to '/root/.config/neofetch' for user 'root'\n"
# NEOFETCH ROOT REMOVE CURRENT BACKUP
printf "Removing 'current' neofetch backup configuration file '/root/backups/neofetch/current/config.conf' for user 'root'\n"
rm -v "/root/backups/neofetch/current/config.conf"
printf "Removed 'current' neofetch backup configuration file '/root/backups/neofetch/current/config.conf' for user 'root'\n"
# NEOFETCH ROOT COPY NEW TO CURRENT BACKUP
printf "Copying current neofetch configuration file '/root/.config/neofetch/config.conf' to '/root/backups/neofetch/current' for user 'root'\n"
cp -pv "/root/.config/neofetch/config.conf" "/root/backups/neofetch/current"
printf "Copied current neofetch configuration file '/root/.config/neofetch/config.conf' to '/root/backups/neofetch/current' for user 'root'\n"

# HTOP
#-----------------------------------------
# USER
printf "Removing current htop configuration file '/home/animo/.config/htop/htoprc' for user 'animo'\n"
rm -v "/home/animo/.config/htop/htoprc"
printf "Removed current htop configuration file '/home/animo/.config/htop/htoprc' for user 'animo'\n"
printf "Copying 'red' htop configuration file '/home/animo/backups/htop/red/htoprc' to '/home/animo/.config/htop' for user 'animo'\n"
cp -pv "/home/animo/backups/htop/red/htoprc" "/home/animo/.config/htop"
printf "Copied 'red' htop configuration file '/home/animo/backups/htop/red/htoprc' to '/home/animo/.config/htop' for user 'animo'\n"
# HTOP USER REMOVE CURRENT BACKUP
printf "Removing 'current' htop backup configuration file '/home/animo/backups/htop/current/htoprc' for user 'animo'\n"
rm -v "/home/animo/backups/htop/current/htoprc"
printf "Removed 'current' htop backup configuration file '/home/animo/backups/htop/current/htoprc' for user 'animo\n"
# HTOP USER COPY NEW TO CURRENT BACKUP
printf "Copying current htop configuration file '/home/animo/.config/htop/htoprc' to '/home/animo/backups/htop/current' for user 'animo'\n"
cp -pv "/home/animo/.config/htop/htoprc" "/home/animo/backups/htop/current"
printf "Copied current htop configuration file '/home/animo/.config/htop/htoprc' to '/home/animo/backups/htop/current' for user 'animo'\n"
# ROOT
printf "Removing current htop configuration file '/root/.config/htop/htoprc' for user 'root'\n"
rm -v "/root/.config/htop/htoprc"
printf "Removed current htop configuration file '/root/.config/htop/htoprc for user 'root'\n"
printf "Copying 'red' htop configuration file '/root/backups/htop/red/htoprc' to '/root/.config/htop' for user 'root'\n"
cp -pv "/root/backups/htop/red/htoprc" "/root/.config/htop"
printf "Copied 'red' htop configuration file '/root/backups/htop/red/htoprc to '/root/.config/htop' for user 'root'\n"
# HTOP ROOT REMOVE CURRENT BACKUP
printf "Removing current htop backup configuration file '/root/backups/htop/current/htoprc' for user 'root'\n"
rm -v "/root/backups/htop/current/htoprc"
printf "Removed current htop backup configuration file '/root/backups/htop/current/htoprc' for user 'root'\n"
# HTOP ROOT COPY NEW TO CURRENT BACKUP
printf "Copying current htop configuration file '/root/.config/htop/htoprc' to '/root/backups/htop/current' for user 'root'\n"
cp -pv "/root/.config/htop/htoprc" "/root/backups/htop/current"
printf "Copied current htop configuration file '/root/.config/htop/htoprc' to '/root/backups/htop/current' for user 'root'\n"

# .BASHRC
#-----------------------------------------
# USER
printf "Removing current '.bashrc' file '/home/animo/.bashrc' for user 'animo'\n"
rm -v "/home/animo/.bashrc"
printf "Removed current '.bashrc' file '/home/animo/.bashrc' for user 'animo'\n"
printf "Copying 'red' '.bashrc' file '/home/animo/backups/dotfiles/.bashrc/red/.bashrc' to '/home/animo' for user 'animo'\n"
cp -pv "/home/animo/backups/dotfiles/.bashrc/red/.bashrc" "/home/animo"
printf "Copied 'red' '.bashrc' file '/home/animo/backups/dotfiles/.bashrc/red/.bashrc' to '/home/animo' for user 'animo'\n"
# .BASHRC USER REMOVE CURRENT BACKUP
printf "Removing current '.bashrc' backup file '/home/animo/backups/dotfiles/.bashrc/current/.bashrc' for user 'animo'\n"
rm -v "/home/animo/backups/dotfiles/.bashrc/current/.bashrc"
printf "Removed current '.bashrc' backup file '/home/animo/backups/dotfiles/.bashrc/current/.bashrc' for user 'animo'\n"
# .BASHRC USER COPY NEW TO CURRENT BACKUP
printf "Copying current '.bashrc' file '/home/animo/.bashrc' to '/home/animo/backups/dotfiles/.bashrc/current' for user 'animo'\n"
cp -pv "/home/animo/.bashrc" "/home/animo/backups/dotfiles/.bashrc/current"
printf "Copied current '.bashrc file '/home/animo/.bashrc' to '/home/animo/backups/dotfiles/.bashrc/current' for user 'animo'\n"
# ROOT
printf "Removing current '.bashrc' file '/root/.bashrc' for user 'root'\n"
rm -v "/root/.bashrc"
printf "Removed '.bashrc' file '/root/.bashrc' for user 'root'\n"
printf "Copying 'red' '.bashrc' file '/root/backups/dotfiles/.bashrc/red/.bashrc' to '/root' for user 'root'\n"
cp -pv "/root/backups/dotfiles/.bashrc/red/.bashrc" "/root"
printf "Copied 'red' '.bashrc' file '/root/backups/dotfiles/.bashrc/red/.bashrc' to '/root' for user 'root'\n"
# .BASHRC ROOT REMOVE CURRENT BACKUP
printf "Removing current '.bashrc' backup file '/root/backups/dotfiles/.bashrc/current/.bashrc' for user 'root'\n"
rm -v "/root/backups/dotfiles/.bashrc/current/.bashrc"
printf "Removed current '.bashrc' backup file '/root/backups/dotfiles/.bashrc/current/.bashrc' for user 'root'\n"
# .BASHRC ROOT COPY NEW TO CURRENT BACKUP
printf "Copying current '.bashrc' file '/root/.bashrc' to '/root/backups/dotfiles/.bashrc/current' for user 'root'\n"
cp -pv "/root/.bashrc" "/root/backups/dotfiles/.bashrc/current"
printf "Copied current '.bashrc' file '/root/.bashrc' to '/root/backups/dotfiles/.bashrc/current' for user 'root'\n"

# SUCKLESS ST UNINSTALL
#-----------------------------------------
printf "Uninstalling currently installed 'st terminal emulator'\n"
make -C "/home/animo/suckless/st/" clean uninstall
printf "Uninstalled 'st terminal emulator'\n"
printf "Removing old 'st terminal emulator directory' '/home/animo/suckless/st'\n"
rm -rv "/home/animo/suckless/st"
printf "Removed old 'st terminal emulator directory' '/home/animo/suckless/st'\n"

# SUCKLESS DWM UNINSTALL
#-----------------------------------------
printf "Uninstalling currently installed 'dwm window manager'\n"
make -C "/home/animo/suckless/dwm" clean uninstall
printf "Uninstalled 'dwm window manager'\n"
printf "Removing old 'dwm window manager' directory '/home/animo/suckless/dwm'\n"
rm -rv "/home/animo/suckless/dwm"
printf "Removed old 'dwm window manager' directory '/home/animo/suckless/dwm'\n"

# SUCKLESS DWM DELETE CURRENT BACKUP 
#-----------------------------------------
printf "Removing old 'dwm window manager' files in '/home/animo/backups/suckless/dwm/current'\n"
rm -rv "/home/animo/backups/suckless/dwm/current"
mkdir -p "/home/animo/backups/suckless/dwm/current"
printf "Removed old 'dwm window manager' files in '/home/animo/backups/suckless/dwm/current'\n"

# SUCKLESS ST DELETE CURRENT BACKUP
#-----------------------------------------
printf "Removing old 'st terminal emulator' files in '/home/animo/backups/suckless/st/current' for user 'animo'\n"
rm -rv "/home/animo/backups/suckless/st/current"
mkdir -p "/home/animo/backups/suckless/st/current"
printf "Removed old 'st terminal emulator' files in '/home/animo/backups/suckless/st/current' for user 'animo'\n"

# .XINITRC
#-----------------------------------------
printf "Removing current '.xinitrc' file '/home/animo/.xinitrc' for user 'animo'\n"
rm -v "/home/animo/.xinitrc"
printf "Removed current '.xinitrc' file '/home/animo/.xinitrc' for user 'animo'\n"

# .XINITRC DELETE CURRENT BACKUP
#-----------------------------------------
printf "Removing 'current' '.xinitrc' backup file '/home/animo/backups/dotfiles/.xinitrc/current/.xinitrc' for user 'animo'\n"
rm -v "/home/animo/backups/dotfiles/.xinitrc/current/.xinitrc"
printf "Removed 'current' '.xinitrc' backup file '/home/animo/backups/dotfiles/.xinitrc/current/.xinitrc' for user 'animo'\n"

# .BASH_PROFILE
#-----------------------------------------
printf "Removing current '.bash_profile' file '/home/animo/.bash_profile' for user 'animo'\n"
rm -v "/home/animo/.bash_profile"
printf "Removed current '.bash_profile' file '/home/animo/.bash_profile' for user 'animo'\n"
printf "Copying 'nox' '.bash_profile' file '/home/animo/backups/dotfiles/.bash_profile/nox/.bash_profile' to '/home/animo' for user 'animo'\n"
cp -pv "/home/animo/backups/dotfiles/.bash_profile/nox/.bash_profile" "/home/animo"
printf "Copied 'nox' '.bash_profile' file '/home/animo/backups/dotfiles/.bash_profile/x/.bash_profile' to '/home/animo' for user 'animo'\n"

# .BASH_PROFILE REMOVE CURRENT BACKUP
#-----------------------------------------
printf "Removing 'current' '.bash_profile' backup file '/home/animo/backups/dotfiles/.bash_profile/current/.bash_profile' for user 'animo'\n"
rm -v "/home/animo/backups/dotfiles/.bash_profile/current/.bash_profile"
printf "Removed 'current' '.bash_profile' backup file '/home/animo/backups/dotfiles/.bash_profile/current/.bash_profile' for user 'animo\n"

# .BASH_PROFILE COPY NEW CURRENT BACKUP
#-----------------------------------------
printf "Copying current '.bash_profile' file '/home/animo/.bash_profile' to '/home/animo/backups/dotfiles/.bash_profile/current' for user 'animo'\n"
cp -pv "/home/animo/.bash_profile" "/home/animo/backups/dotfiles/.bash_profile/current"
printf "Copied current '.bash_profile' file '/home/animo/.bash_profile' to '/home/animo/backups/dotfiles/.bash_profile/current' for user 'animo'\n"

printf "Done.\n"
