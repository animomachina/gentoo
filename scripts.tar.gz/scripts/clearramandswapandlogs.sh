#!/bin/sh
rm -f "/root/.config/bashtop/error.log"
rm -f "/home/animo/.config/bashtop/error.log"
rm -f "/home/animo/.local/share/xorg/Xorg.1.log"
rm -f "/var/log/Xorg.0.log"
rm -f "/var/log/Xorg.1.log"
rm -f "/var/log/pacman.log"
rm -f "/home/animo/.local/share/xorg/Xorg.0.log"
swapoff -a && swapon -a
sync; echo 3 > /proc/sys/vm/drop_caches
printf "Cleared RAM and swap and logs.\n"
