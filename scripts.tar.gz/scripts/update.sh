#!/bin/sh
emaint --auto sync
emerge -auvND --with-bdeps=y --complete-graph @world
read -n 1 -s -r -p "Press any key to continue."$'\n'
etc-update
exit
